// CC Smart Health - Enhanced Production Router v2.0
class HealthRouter {
    constructor() {
        this.routes = {
            '/': 'home',
            '/index.html': 'home',
            '/about.html': 'about',
            '/services.html': 'services',
            '/doctors.html': 'doctors',
            '/appointment.html': 'appointment',
            '/pharmacy.html': 'pharmacy',
            '/lab-tests.html': 'lab-tests',
            '/contact.html': 'contact',
            '/help.html': 'help',
            '/patient-dashboard.html': 'patient-dashboard',
            '/admin-login.html': 'admin-login',
            '/admin-dashboard.html': 'admin-dashboard',
            '/staff-login.html': 'staff-login'
        };
        
        this.currentRoute = '';
        this.previousRoute = '';
        this.isNavigating = false;
        this.navigationTimeout = null;
        
        this.init();
    }

    init() {
        console.log('🛣️ Health Router: Initializing...');
        
        this.bindEvents();
        this.handleRouteChange();
        this.setupNavigationObserver();
        
        console.log('✅ Health Router initialized successfully');
    }

    bindEvents() {
        // Enhanced navigation with progress indicators
        document.addEventListener('click', (e) => {
            const link = e.target.closest('a[href]');
            if (link && this.isInternalLink(link)) {
                e.preventDefault();
                this.handleNavigation(link);
            }
        });

        // Handle browser back/forward
        window.addEventListener('popstate', () => {
            this.handleRouteChange();
        });

        // Handle page visibility for returning to tab
        document.addEventListener('visibilitychange', () => {
            if (!document.hidden) {
                this.handleRouteChange();
            }
        });

        // Handle page load completion
        window.addEventListener('load', () => {
            this.handleRouteChange();
        });
    }

    isInternalLink(link) {
        const href = link.getAttribute('href');
        return href && (href.startsWith('/') || href.startsWith('./') || href.startsWith('../'));
    }

    async handleNavigation(link) {
        if (this.isNavigating) {
            console.log('🚫 Navigation already in progress');
            return;
        }
        
        const href = link.getAttribute('href');
        const target = link.getAttribute('target');
        
        // Handle external links and new tabs
        if (target === '_blank' || href.startsWith('http') || href.startsWith('mailto:') || href.startsWith('tel:')) {
            if (target === '_blank') {
                window.open(href, '_blank');
            } else {
                window.location.href = href;
            }
            return;
        }

        this.isNavigating = true;
        
        try {
            // Show loading state
            this.showNavigationProgress();
            
            // Close mobile menu if open
            this.closeMobileMenu();
            
            // Update URL without page reload
            window.history.pushState({}, '', href);
            
            // Handle route change with smooth transition
            await this.handleRouteChange();
            
            // Smooth scroll to top
            window.scrollTo({ top: 0, behavior: 'smooth' });
            
            // Track navigation for analytics
            this.trackNavigation(href);
            
        } catch (error) {
            console.error('❌ Navigation error:', error);
            this.showNavigationError(href);
        } finally {
            this.isNavigating = false;
            this.hideNavigationProgress();
        }
    }

    async handleRouteChange() {
        const path = window.location.pathname;
        
        // Don't process if route hasn't changed
        if (path === this.currentRoute) return;
        
        console.log(`🔄 Route change: ${this.currentRoute} -> ${path}`);
        
        this.previousRoute = this.currentRoute;
        this.currentRoute = path;
        
        // Update UI elements
        this.updateActiveNav(path);
        this.updatePageTitle(path);
        this.updateMetaDescription(path);
        
        // Execute route-specific actions
        await this.executeRouteActions(path);
        
        // Accessibility announcement
        this.announceRouteChange(path);
        
        // Trigger custom event for other components
        this.triggerPageChangeEvent(path);
    }

    updateActiveNav(path) {
        const navLinks = document.querySelectorAll('.nav-link');
        let foundActive = false;
        
        navLinks.forEach(link => {
            const linkHref = link.getAttribute('href');
            const linkPath = this.normalizePath(linkHref);
            const currentPath = this.normalizePath(path);
            
            if (linkPath === currentPath) {
                link.classList.add('active');
                foundActive = true;
            } else {
                link.classList.remove('active');
            }
        });
        
        // Fallback: if no active link found, activate home
        if (!foundActive) {
            const homeLink = document.querySelector('.nav-link[href="/"], .nav-link[href="/index.html"], .nav-link[data-page="home"]');
            if (homeLink) {
                homeLink.classList.add('active');
            }
        }
    }

    updatePageTitle(path) {
        const routeName = this.routes[path] || this.routes['/'];
        const baseTitle = 'CC Smart Health';
        
        let pageTitle = baseTitle;
        
        if (routeName !== 'home') {
            const pageName = this.formatRouteName(routeName);
            pageTitle = `${pageName} | ${baseTitle}`;
        }
        
        document.title = pageTitle;
        
        // Update meta tags for social sharing
        this.updateMetaTags(pageTitle, routeName);
    }

    updateMetaDescription(path) {
        const descriptions = {
            'home': 'Your trusted healthcare partner in Hoima City. Quality medical care, laboratory tests, pharmacy, and telemedicine services.',
            'about': 'Learn about CC Smart Health - our mission, values, and commitment to providing quality healthcare services in Hoima City.',
            'services': 'Comprehensive healthcare services including medical consultations, laboratory testing, pharmacy, and emergency care.',
            'appointment': 'Book your medical appointment online with CC Smart Health. Easy scheduling for consultations and services.',
            'pharmacy': 'Complete pharmacy services with prescription and over-the-counter medications. Delivery available throughout Hoima City.'
        };
        
        const routeName = this.routes[path] || 'home';
        const description = descriptions[routeName] || descriptions['home'];
        
        let metaDesc = document.querySelector('meta[name="description"]');
        if (!metaDesc) {
            metaDesc = document.createElement('meta');
            metaDesc.name = 'description';
            document.head.appendChild(metaDesc);
        }
        metaDesc.content = description;
    }

    updateMetaTags(pageTitle, routeName) {
        // Update Open Graph tags
        this.updateMetaTag('property', 'og:title', pageTitle);
        this.updateMetaTag('property', 'og:url', window.location.href);
        
        // Update Twitter cards
        this.updateMetaTag('name', 'twitter:title', pageTitle);
    }

    updateMetaTag(attr, name, content) {
        let metaTag = document.querySelector(`meta[${attr}="${name}"]`);
        if (!metaTag) {
            metaTag = document.createElement('meta');
            metaTag.setAttribute(attr, name);
            document.head.appendChild(metaTag);
        }
        metaTag.content = content;
    }

    async executeRouteActions(path) {
        const route = this.routes[path] || 'home';
        
        try {
            // Execute route-specific initialization
            switch (route) {
                case 'pharmacy':
                    await this.initializePharmacyPage();
                    break;
                case 'lab-tests':
                    await this.initializeLabTestsPage();
                    break;
                case 'appointment':
                    await this.initializeAppointmentPage();
                    break;
                case 'admin-dashboard':
                    await this.initializeAdminDashboard();
                    break;
                case 'admin-login':
                case 'staff-login':
                    await this.initializeLoginPage();
                    break;
            }
            
            console.log(`✅ ${this.formatRouteName(route)} page initialized`);
            
        } catch (error) {
            console.error(`❌ Error initializing ${route} page:`, error);
        }
    }

    async initializePharmacyPage() {
        if (window.ccHealthApp && typeof window.ccHealthApp.initPharmacyPage === 'function') {
            await window.ccHealthApp.initPharmacyPage();
        }
    }

    async initializeLabTestsPage() {
        if (window.ccHealthApp && typeof window.ccHealthApp.initLabTestsPage === 'function') {
            await window.ccHealthApp.initLabTestsPage();
        }
    }

    async initializeAppointmentPage() {
        if (window.ccHealthApp && typeof window.ccHealthApp.initAppointmentPage === 'function') {
            await window.ccHealthApp.initAppointmentPage();
        }
    }

    async initializeAdminDashboard() {
        if (window.ccHealthApp && typeof window.ccHealthApp.initAdminDashboard === 'function') {
            await window.ccHealthApp.initAdminDashboard();
        }
    }

    async initializeLoginPage() {
        if (window.ccHealthApp && typeof window.ccHealthApp.initLoginPage === 'function') {
            await window.ccHealthApp.initLoginPage();
        }
    }

    triggerPageChangeEvent(path) {
        const route = this.routes[path] || 'home';
        const event = new CustomEvent('pagechanged', {
            detail: {
                route: route,
                path: path,
                previousRoute: this.previousRoute,
                timestamp: new Date().toISOString()
            }
        });
        document.dispatchEvent(event);
    }

    announceRouteChange(path) {
        const routeName = this.routes[path] || 'home';
        const pageName = this.formatRouteName(routeName);
        
        const announcement = document.getElementById('route-announcement') || this.createAnnouncementElement();
        announcement.textContent = `Navigated to ${pageName} page`;
        
        // Clear announcement after 3 seconds
        setTimeout(() => {
            announcement.textContent = '';
        }, 3000);
    }

    createAnnouncementElement() {
        const announcement = document.createElement('div');
        announcement.id = 'route-announcement';
        announcement.setAttribute('aria-live', 'polite');
        announcement.setAttribute('aria-atomic', 'true');
        announcement.style.cssText = `
            position: absolute;
            left: -10000px;
            top: auto;
            width: 1px;
            height: 1px;
            overflow: hidden;
        `;
        document.body.appendChild(announcement);
        return announcement;
    }

    showNavigationProgress() {
        // Clear any existing timeout
        if (this.navigationTimeout) {
            clearTimeout(this.navigationTimeout);
        }
        
        let progressBar = document.getElementById('navigation-progress');
        
        if (!progressBar) {
            progressBar = document.createElement('div');
            progressBar.id = 'navigation-progress';
            progressBar.style.cssText = `
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 3px;
                background: linear-gradient(90deg, var(--medical-blue), var(--medical-green));
                z-index: 10000;
                transform: scaleX(0);
                transform-origin: left;
                transition: transform 0.4s ease;
                box-shadow: 0 1px 3px rgba(0,0,0,0.2);
            `;
            document.body.appendChild(progressBar);
        }
        
        // Start progress animation
        progressBar.style.transform = 'scaleX(0.3)';
        
        // Simulate progress
        this.navigationTimeout = setTimeout(() => {
            if (progressBar) {
                progressBar.style.transform = 'scaleX(0.7)';
            }
        }, 100);
    }

    hideNavigationProgress() {
        const progressBar = document.getElementById('navigation-progress');
        if (progressBar) {
            progressBar.style.transform = 'scaleX(1)';
            
            // Remove after animation completes
            setTimeout(() => {
                if (progressBar && progressBar.parentNode) {
                    progressBar.parentNode.removeChild(progressBar);
                }
            }, 400);
        }
        
        // Clear timeout
        if (this.navigationTimeout) {
            clearTimeout(this.navigationTimeout);
            this.navigationTimeout = null;
        }
    }

    showNavigationError(href) {
        if (window.ccHealthApp && typeof window.ccHealthApp.showNotification === 'function') {
            window.ccHealthApp.showNotification(
                'Navigation Error',
                `Failed to load ${href}. Please try again.`,
                'error',
                5000
            );
        }
    }

    closeMobileMenu() {
        const nav = document.querySelector('.main-nav');
        const overlay = document.querySelector('.nav-overlay');
        
        if (nav) nav.classList.remove('active');
        if (overlay) overlay.classList.remove('active');
        document.body.style.overflow = '';
    }

    setupNavigationObserver() {
        // Observe for dynamically added links
        const observer = new MutationObserver((mutations) => {
            mutations.forEach((mutation) => {
                mutation.addedNodes.forEach((node) => {
                    if (node.nodeType === 1) {
                        const links = node.querySelectorAll ? node.querySelectorAll('a[href]') : [];
                        links.forEach(link => {
                            if (this.isInternalLink(link) && !link.hasAttribute('data-routed')) {
                                link.setAttribute('data-routed', 'true');
                                link.addEventListener('click', (e) => {
                                    if (!e.ctrlKey && !e.metaKey && !e.shiftKey) {
                                        e.preventDefault();
                                        this.handleNavigation(link);
                                    }
                                });
                            }
                        });
                    }
                });
            });
        });

        observer.observe(document.body, {
            childList: true,
            subtree: true
        });
    }

    trackNavigation(path) {
        const navigationEvent = {
            type: 'navigation',
            from: this.previousRoute,
            to: path,
            timestamp: new Date().toISOString(),
            userAgent: navigator.userAgent,
            referrer: document.referrer
        };
        
        try {
            const navHistory = JSON.parse(localStorage.getItem('nav_history') || '[]');
            navHistory.push(navigationEvent);
            
            // Keep only last 100 navigations
            if (navHistory.length > 100) {
                navHistory.splice(0, navHistory.length - 100);
            }
            
            localStorage.setItem('nav_history', JSON.stringify(navHistory));
        } catch (error) {
            console.warn('Could not track navigation:', error);
        }
    }

    // Utility methods
    normalizePath(path) {
        if (!path) return '/';
        if (path === '/' || path === '/index.html' || path === './' || path === '../') return '/';
        return path.startsWith('/') ? path : '/' + path;
    }

    formatRouteName(routeName) {
        return routeName.split('-')
            .map(word => word.charAt(0).toUpperCase() + word.slice(1))
            .join(' ');
    }

    // Public API methods
    navigateTo(path) {
        const link = document.createElement('a');
        link.href = path;
        this.handleNavigation(link);
    }

    getCurrentRoute() {
        return {
            path: this.currentRoute,
            name: this.routes[this.currentRoute] || 'home',
            previous: this.previousRoute
        };
    }

    getNavigationHistory() {
        try {
            return JSON.parse(localStorage.getItem('nav_history') || '[]');
        } catch (error) {
            return [];
        }
    }

    clearNavigationHistory() {
        localStorage.removeItem('nav_history');
        return { success: true, message: 'Navigation history cleared' };
    }

    // Check if route exists
    routeExists(path) {
        return !!this.routes[this.normalizePath(path)];
    }

    // Get all available routes
    getAvailableRoutes() {
        return Object.keys(this.routes).map(path => ({
            path: path,
            name: this.routes[path],
            displayName: this.formatRouteName(this.routes[path])
        }));
    }
}

// Enhanced initialization with better error handling
function initializeRouter() {
    try {
        // Wait for DOM to be fully ready
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => {
                window.healthRouter = new HealthRouter();
            });
        } else {
            window.healthRouter = new HealthRouter();
        }
        
        // Export router for global access
        window.HealthRouter = HealthRouter;
        
    } catch (error) {
        console.error('❌ Failed to initialize Health Router:', error);
        
        // Comprehensive fallback
        document.addEventListener('click', (e) => {
            const link = e.target.closest('a[href]');
            if (link && link.getAttribute('href').startsWith('/')) {
                // Only prevent default for same-origin navigation
                if (!link.target || link.target === '_self') {
                    e.preventDefault();
                    window.location.href = link.getAttribute('href');
                }
            }
        });
        
        console.log('🔄 Using fallback navigation system');
    }
}

// Auto-initialize router
initializeRouter();