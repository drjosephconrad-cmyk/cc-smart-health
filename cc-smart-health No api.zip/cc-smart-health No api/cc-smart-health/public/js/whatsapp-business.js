// CC Smart Health - Enhanced WhatsApp Business Service
class WhatsAppBusinessService {
    constructor() {
        this.businessPhone = '+256762235149';
        this.whatsappPhone = '+256776769841';
        this.labPhone = '+256773361879';
        this.backupPhone = '+256762235149';
    }

    // Enhanced Appointment Booking with better formatting
    static sendAppointment(appointmentData) {
        const appointmentCode = 'APT' + Date.now().toString().slice(-6);
        const estimatedFee = this.calculateFee(appointmentData.service_type);
        
        const message = `📅 NEW APPOINTMENT REQUEST - CC SMART HEALTH
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🆔 **Appointment Code:** ${appointmentCode}
⏰ **Received:** ${new Date().toLocaleString('en-UG')}

👤 **PATIENT INFORMATION**
• Full Name: ${appointmentData.patient_name}
• Phone: ${appointmentData.patient_phone}
• Location: ${appointmentData.location || 'Hoima City'}
${appointmentData.emergency_contact ? `• Emergency Contact: ${appointmentData.emergency_contact}` : ''}

🩺 **APPOINTMENT DETAILS**
• Service Type: ${this.formatServiceType(appointmentData.service_type)}
• Consultation: ${appointmentData.consultation_type === 'online' ? '📱 Online' : '🏥 In-Person'}
• Preferred Date: ${appointmentData.appointment_date}
• Preferred Time: ${appointmentData.appointment_time}

📋 **MEDICAL INFORMATION**
${appointmentData.symptoms ? `• Symptoms: ${appointmentData.symptoms}` : '• No symptoms provided'}
${appointmentData.special_requirements ? `• Special Requirements: ${appointmentData.special_requirements}` : ''}

💰 **ESTIMATED COST:** UGX ${estimatedFee.toLocaleString()}

⚠️ **ACTION REQUIRED**
1. Contact patient to confirm appointment
2. Check doctor availability
3. Provide confirmation to patient

🏥 **CC Smart Health**
📍 Hoima City | 📞 0762235149
⏰ 24/7 Emergency Services`;

        // Send to main business number
        this.sendToBusiness(message, 'appointment');
        
        return { 
            success: true, 
            appointment_code: appointmentCode,
            fee: estimatedFee,
            message: 'Appointment request sent successfully',
            timestamp: new Date().toISOString()
        };
    }

    // Enhanced Pharmacy Orders with item details
    static sendPharmacyOrder(orderData) {
        const orderCode = 'PHARM' + Date.now().toString().slice(-6);
        const itemsSummary = this.formatOrderItems(orderData.items);
        const deliveryInfo = this.getDeliveryInfo(orderData.delivery_address);
        
        const message = `💊 NEW PHARMACY ORDER - CC SMART HEALTH
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🆔 **Order Code:** ${orderCode}
⏰ **Received:** ${new Date().toLocaleString('en-UG')}

👤 **CUSTOMER INFORMATION**
• Name: ${orderData.customer_name}
• Phone: ${orderData.customer_phone}
• Delivery Address: ${orderData.delivery_address}

🛒 **ORDER SUMMARY**
${itemsSummary}

💰 **PAYMENT BREAKDOWN**
• Subtotal: UGX ${orderData.subtotal.toLocaleString()}
• Delivery Fee: UGX ${orderData.delivery_fee.toLocaleString()}
• **TOTAL: UGX ${orderData.total_amount.toLocaleString()}**
• Payment Method: ${this.formatPaymentMethod(orderData.payment_method)}

🚚 **DELIVERY INFORMATION**
• Area: ${deliveryInfo.area}
• Estimated Delivery: ${deliveryInfo.time}
• Delivery Notes: ${orderData.special_instructions || 'Standard delivery'}

⚠️ **ACTION REQUIRED**
1. Check stock availability
2. Confirm order with customer
3. Prepare for delivery
4. Update order status

🏥 **CC Smart Health Pharmacy**
📍 Hoima City | 📞 0762235149
🚚 Free delivery on orders over UGX 50,000`;

        // Send to main business number
        this.sendToBusiness(message, 'pharmacy_order');
        
        return { 
            success: true, 
            order_code: orderCode,
            total_amount: orderData.total_amount,
            delivery_time: deliveryInfo.time,
            message: 'Pharmacy order submitted successfully',
            timestamp: new Date().toISOString()
        };
    }

    // Enhanced Lab Test Requests
    static sendLabTestRequest(labData) {
        const requestCode = 'LAB' + Date.now().toString().slice(-6);
        const testsSummary = this.formatLabTests(labData.tests);
        
        const message = `🔬 NEW LAB TEST REQUEST - CC SMART HEALTH
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🆔 **Request Code:** ${requestCode}
⏰ **Received:** ${new Date().toLocaleString('en-UG')}

👤 **PATIENT INFORMATION**
• Name: ${labData.patient_name}
• Phone: ${labData.patient_phone}
${labData.patient_email ? `• Email: ${labData.patient_email}` : ''}

🧪 **REQUESTED TESTS**
${testsSummary}

💰 **TOTAL AMOUNT:** UGX ${labData.total_amount.toLocaleString()}

📋 **SPECIAL INSTRUCTIONS**
${labData.special_instructions || 'No special instructions provided'}

⚠️ **ACTION REQUIRED - LAB TEAM**
1. Contact patient for sample collection
2. Schedule appointment if needed
3. Provide results timeline
4. Update request status

🔬 **CC Smart Health Laboratory**
📍 Hoima City | 📞 0773361879
⏰ Results within 24-48 hours`;

        // Send to both main business and lab numbers
        this.sendToBusiness(message, 'lab_request');
        this.sendToLab(message);
        
        return { 
            success: true, 
            request_code: requestCode,
            total_amount: labData.total_amount,
            message: 'Lab test request submitted successfully',
            timestamp: new Date().toISOString()
        };
    }

    // Enhanced Staff Login Notification
    static sendStaffLogin(credentials, deviceInfo) {
        const message = `🔐 STAFF LOGIN DETECTED - CC SMART HEALTH
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

👤 **Login Details**
• Username: ${credentials.username}
• Time: ${new Date().toLocaleString('en-UG')}
• Device: ${deviceInfo}
• IP: [Auto-detected by WhatsApp]

📍 **Security Check**
✅ This is a legitimate login attempt
✅ User: ${credentials.username}
✅ Time: ${new Date().toLocaleTimeString('en-UG')}

⚠️ **Security Reminder**
• Always verify sensitive actions
• Log out when not in use
• Report suspicious activity immediately

🏥 **CC Smart Health Admin System**
🔒 Secure Access | 📊 Activity Logged`;

        this.sendToBusiness(message, 'staff_login');
        return { success: true };
    }

    // New: Staff Logout Notification
    static sendStaffLogout(session) {
        const message = `🔐 STAFF LOGOUT - CC SMART HEALTH
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

👤 **Session Ended**
• User: ${session.full_name} (${session.username})
• Role: ${session.role}
• Login Duration: ${this.calculateSessionDuration(session.login_time)}
• Logout Time: ${new Date().toLocaleString('en-UG')}

✅ **Security Status**
• Session properly terminated
• All sensitive data secured
• System access revoked

🏥 **CC Smart Health Admin System**
🔒 Security First | 📊 Activity Monitored`;

        this.sendToBusiness(message, 'staff_logout');
        return { success: true };
    }

    // Enhanced Utility Methods
    static formatOrderItems(items) {
        return items.map(item => 
            `• ${item.name} x${item.quantity} = UGX ${(item.price * item.quantity).toLocaleString()}`
        ).join('\n');
    }

    static formatLabTests(tests) {
        return tests.map(test => 
            `• ${test.name} - UGX ${test.price.toLocaleString()}`
        ).join('\n');
    }

    static calculateFee(serviceType) {
        const fees = {
            'clinic': 15000,
            'home-visit': 20000,
            'online': 10000,
            'lab-test': 0,
            'emergency': 25000
        };
        return fees[serviceType] || 15000;
    }

    static formatServiceType(serviceType) {
        const types = {
            'clinic': '🏥 Clinic Visit',
            'home-visit': '🏠 Home Visit',
            'online': '📱 Online Consultation',
            'lab-test': '🔬 Laboratory Test',
            'emergency': '🚑 Emergency Care'
        };
        return types[serviceType] || serviceType;
    }

    static formatPaymentMethod(method) {
        const methods = {
            'mobile_money': '📱 Mobile Money',
            'cash': '💵 Cash on Delivery',
            'bank': '🏦 Bank Transfer'
        };
        return methods[method] || method;
    }

    static getDeliveryInfo(address) {
        const areas = {
            'Hoima City': { area: 'Hoima City Center', time: '2-4 hours' },
            'Kijungu': { area: 'Kijungu', time: '3-5 hours' },
            'Bujumbura': { area: 'Bujumbura', time: '4-6 hours' }
        };
        
        for (const [key, value] of Object.entries(areas)) {
            if (address.includes(key)) {
                return value;
            }
        }
        
        return { area: 'Hoima Region', time: '4-6 hours' };
    }

    static calculateSessionDuration(loginTime) {
        const login = new Date(loginTime);
        const logout = new Date();
        const diff = logout - login;
        
        const hours = Math.floor(diff / (1000 * 60 * 60));
        const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
        
        return `${hours}h ${minutes}m`;
    }

    // Enhanced sending methods with error handling
    static sendToBusiness(message, type = 'general') {
        try {
            const encodedMessage = encodeURIComponent(message);
            window.open(`https://wa.me/${this.businessPhone}?text=${encodedMessage}`, '_blank');
            
            // Log the message send attempt
            this.logMessageSend(type, 'business', true);
        } catch (error) {
            console.error('Failed to send WhatsApp message to business:', error);
            this.logMessageSend(type, 'business', false, error.message);
        }
    }

    static sendToLab(message) {
        try {
            const encodedMessage = encodeURIComponent(message);
            window.open(`https://wa.me/${this.labPhone}?text=${encodedMessage}`, '_blank');
            
            this.logMessageSend('lab_request', 'lab', true);
        } catch (error) {
            console.error('Failed to send WhatsApp message to lab:', error);
            this.logMessageSend('lab_request', 'lab', false, error.message);
        }
    }

    static logMessageSend(type, recipient, success, error = null) {
        const logEntry = {
            type: type,
            recipient: recipient,
            success: success,
            timestamp: new Date().toISOString(),
            error: error
        };
        
        // Store in localStorage for debugging
        try {
            const logs = JSON.parse(localStorage.getItem('whatsapp_logs') || '[]');
            logs.push(logEntry);
            
            // Keep only last 50 logs
            if (logs.length > 50) {
                logs.splice(0, logs.length - 50);
            }
            
            localStorage.setItem('whatsapp_logs', JSON.stringify(logs));
        } catch (e) {
            console.warn('Could not log WhatsApp message:', e);
        }
    }

    // Utility method for direct messages
    static sendMessage(message, phone = null) {
        const targetPhone = phone || this.businessPhone;
        const encodedMessage = encodeURIComponent(message);
        
        window.open(`https://wa.me/${targetPhone}?text=${encodedMessage}`, '_blank');
        
        return { success: true, phone: targetPhone };
    }

    // Method to get message logs (for debugging)
    static getMessageLogs() {
        try {
            return JSON.parse(localStorage.getItem('whatsapp_logs') || '[]');
        } catch (error) {
            return [];
        }
    }

    // Method to clear message logs
    static clearMessageLogs() {
        localStorage.removeItem('whatsapp_logs');
        return { success: true };
    }
}

// Make available globally
window.WhatsAppBusiness = WhatsAppBusinessService;