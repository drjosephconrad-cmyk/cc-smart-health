// CC Smart Health - Production Ready Main Application v3.1
class CCHealthApp {
    constructor() {
        this.router = null;
        this.currentPage = '';
        this.cart = {};
        this.currentStaff = null;
        this.isOnline = navigator.onLine;
        this.init();
    }

    init() {
        console.log('🏥 CC Smart Health App: Initializing...');
        
        // Setup error boundaries first
        this.setupErrorBoundaries();
        
        // Initialize core systems
        this.loadCart();
        this.setupEventListeners();
        this.initServiceWorker();
        this.checkStaffSession();
        this.setupConnectivityMonitoring();
        
        // Verify all dependencies are loaded
        this.verifyJSFiles();
        
        // Initialize page-specific features
        this.initPageSpecificFeatures();
        
        // Debug navigation setup
        this.debugNavigationSetup();
        
        console.log('✅ CC Smart Health App Initialized Successfully');
    }

    setupEventListeners() {
        // Global event delegation for better performance
        document.addEventListener('click', (e) => {
            this.handleGlobalClick(e);
        });

        // Enhanced form handling
        document.addEventListener('submit', (e) => {
            this.handleFormSubmit(e);
        });

        // Online/offline detection
        window.addEventListener('online', () => this.handleOnlineStatus(true));
        window.addEventListener('offline', () => this.handleOnlineStatus(false));

        // Page visibility changes
        document.addEventListener('visibilitychange', () => {
            this.handleVisibilityChange();
        });
    }

    handleGlobalClick(e) {
        const target = e.target;
        
        // WhatsApp buttons
        if (target.closest('[data-whatsapp]')) {
            this.handleWhatsAppClick(e);
            return;
        }
        
        // Emergency buttons
        if (target.closest('.emergency-btn')) {
            this.handleEmergencyCall(e);
            return;
        }
        
        // Add to cart buttons
        if (target.closest('[data-add-to-cart]')) {
            this.handleAddToCartClick(e);
            return;
        }
        
        // Navigation links - ONLY intercept if we have a proper router
        if (target.closest('[data-page]') && window.healthRouter) {
            e.preventDefault();
            this.handleNavigation(e);
            return;
        }
        
        // Mobile menu toggle
        if (target.closest('.menu-toggle')) {
            this.toggleMobileMenu();
            return;
        }

        // Notification close buttons
        if (target.closest('.notification-close')) {
            this.handleNotificationClose(e);
            return;
        }

        // Cart buttons
        if (target.closest('[data-cart-remove]')) {
            this.handleCartRemoveClick(e);
            return;
        }

        if (target.closest('[data-cart-update]')) {
            this.handleCartUpdateClick(e);
            return;
        }
    }

    // FIXED Navigation handling - Only use for SPA, otherwise let browser handle
    handleNavigation(e) {
        const link = e.target.closest('[data-page]');
        const page = link.getAttribute('data-page');
        const href = link.getAttribute('href');
        
        console.log(`🔄 Navigation clicked: ${page} -> ${href}`);
        
        // Close mobile menu first
        this.closeMobileMenu();
        
        // If we have a router, use it for SPA navigation
        if (window.healthRouter && typeof window.healthRouter.navigate === 'function') {
            window.healthRouter.navigate(page);
            return;
        }
        
        // Otherwise, let the browser handle normal navigation
        if (href && href !== '#' && href !== window.location.pathname) {
            console.log(`📄 Loading page: ${href}`);
            // Don't prevent default - let browser handle it naturally
            return;
        }
        
        // Fallback: Show notification for demo purposes
        console.log(`ℹ️ No router available for: ${page}`);
        this.showNotification(
            `${page.charAt(0).toUpperCase() + page.slice(1)}`, 
            'Page navigation handled by browser',
            'info',
            2000
        );
    }

    handleFormSubmit(e) {
        const form = e.target;
        
        // Only handle health forms
        if (!form.classList.contains('health-form')) return;
        
        e.preventDefault();
        
        const formId = form.id || form.getAttribute('name');
        const formData = new FormData(form);
        
        switch(formId) {
            case 'appointmentForm':
                this.handleAppointmentSubmit(formData);
                break;
            case 'pharmacyOrderForm':
                this.handlePharmacyOrderSubmit(formData);
                break;
            case 'labTestForm':
                this.handleLabTestSubmit(formData);
                break;
            case 'staffLoginForm':
                this.handleStaffLogin(formData);
                break;
            case 'contactForm':
                this.handleContactSubmit(formData);
                break;
            default:
                console.warn('Unknown form submitted:', formId);
                this.handleGenericFormSubmit(formData, formId);
        }
    }

    async handleAppointmentSubmit(formData) {
        const appointmentData = {
            patient_name: this.sanitizeInput(formData.get('patient_name')),
            patient_phone: this.formatPhoneNumber(formData.get('patient_phone')),
            service_type: formData.get('service_type'),
            consultation_type: formData.get('consultation_type') || 'in-person',
            appointment_date: formData.get('appointment_date'),
            appointment_time: formData.get('appointment_time'),
            symptoms: this.sanitizeInput(formData.get('symptoms') || ''),
            location: this.sanitizeInput(formData.get('location') || 'Hoima City'),
            emergency_contact: this.formatPhoneNumber(formData.get('emergency_contact') || ''),
            special_requirements: this.sanitizeInput(formData.get('special_requirements') || ''),
            timestamp: new Date().toISOString()
        };

        if (!this.validateAppointmentData(appointmentData)) {
            return;
        }

        this.showLoading('Sending appointment request...');
        
        try {
            const result = await HealthAPI.createAppointment(appointmentData);
            
            if (result.success) {
                this.showNotification(
                    'Appointment Request Sent!', 
                    `We've received your appointment request. Reference: ${result.reference}. We'll contact you shortly to confirm.`,
                    'success'
                );
                
                this.trackEvent('appointment_requested', {
                    service_type: appointmentData.service_type,
                    consultation_type: appointmentData.consultation_type
                });
                
                const form = document.getElementById('appointmentForm');
                if (form) form.reset();
            } else {
                throw new Error(result.error || 'Failed to send appointment');
            }
        } catch (error) {
            console.error('Appointment submission error:', error);
            this.showNotification(
                'Submission Error', 
                error.message || 'Failed to send appointment request. Please try again or call us directly.',
                'error'
            );
        } finally {
            this.hideLoading();
        }
    }

    validateAppointmentData(data) {
        const errors = [];
        
        if (!data.patient_name?.trim()) {
            errors.push('Patient name is required');
        }
        
        if (!data.patient_phone?.trim()) {
            errors.push('Phone number is required');
        } else if (!this.isValidPhoneNumber(data.patient_phone)) {
            errors.push('Please enter a valid phone number');
        }
        
        if (!data.appointment_date) {
            errors.push('Appointment date is required');
        }
        
        if (!data.appointment_time) {
            errors.push('Appointment time is required');
        }
        
        if (errors.length > 0) {
            this.showNotification('Validation Error', errors.join(', '), 'error');
            return false;
        }
        
        return true;
    }

    async handlePharmacyOrderSubmit(formData) {
        const items = Object.keys(this.cart).map(productId => ({
            id: productId,
            name: this.cart[productId].name,
            price: this.cart[productId].price,
            quantity: this.cart[productId].quantity
        }));

        if (items.length === 0) {
            this.showNotification('Error', 'Please add items to your cart', 'error');
            return;
        }

        const orderData = {
            customer_name: this.sanitizeInput(formData.get('customer_name')),
            customer_phone: this.formatPhoneNumber(formData.get('customer_phone')),
            delivery_address: this.sanitizeInput(formData.get('delivery_address')),
            items: items,
            subtotal: this.calculateSubtotal(),
            delivery_fee: 5000,
            total_amount: this.calculateSubtotal() + 5000,
            payment_method: formData.get('payment_method') || 'mobile_money',
            special_instructions: this.sanitizeInput(formData.get('special_instructions') || ''),
            timestamp: new Date().toISOString()
        };

        this.showLoading('Processing your order...');
        
        try {
            const result = await HealthAPI.createPharmacyOrder(orderData);
            
            if (result.success) {
                this.showNotification(
                    'Order Submitted!', 
                    `Your order has been received. Order code: ${result.order_code}. We'll confirm stock and contact you for delivery.`,
                    'success'
                );
                
                this.trackEvent('pharmacy_order_placed', {
                    item_count: items.length,
                    total_amount: orderData.total_amount
                });
                
                this.clearCart();
                const form = document.getElementById('pharmacyOrderForm');
                if (form) form.reset();
            }
        } catch (error) {
            console.error('Pharmacy order error:', error);
            this.showNotification('Order Failed', 'Failed to submit order. Please try again or call us directly.', 'error');
        } finally {
            this.hideLoading();
        }
    }

    // Enhanced shopping cart methods
    loadCart() {
        try {
            const cartData = localStorage.getItem('pharmacy_cart');
            this.cart = cartData ? JSON.parse(cartData) : {};
            this.updateCartDisplay();
        } catch (error) {
            console.error('Error loading cart:', error);
            this.cart = {};
        }
    }

    saveCart() {
        try {
            localStorage.setItem('pharmacy_cart', JSON.stringify(this.cart));
            this.updateCartDisplay();
        } catch (error) {
            console.error('Error saving cart:', error);
        }
    }

    handleAddToCartClick(e) {
        const button = e.target.closest('[data-add-to-cart]');
        const productId = button.getAttribute('data-product-id');
        const productName = button.getAttribute('data-product-name');
        const productPrice = parseFloat(button.getAttribute('data-product-price'));
        const quantity = parseInt(button.getAttribute('data-quantity') || 1);
        
        this.addToCart(productId, productName, productPrice, quantity);
    }

    handleCartRemoveClick(e) {
        const button = e.target.closest('[data-cart-remove]');
        const productId = button.getAttribute('data-product-id');
        this.removeFromCart(productId);
    }

    handleCartUpdateClick(e) {
        const button = e.target.closest('[data-cart-update]');
        const productId = button.getAttribute('data-product-id');
        const change = parseInt(button.getAttribute('data-change'));
        this.updateCartQuantity(productId, change);
    }

    addToCart(productId, productName, productPrice, quantity = 1) {
        if (!this.cart[productId]) {
            this.cart[productId] = {
                name: productName,
                price: parseFloat(productPrice),
                quantity: 0
            };
        }
        this.cart[productId].quantity += parseInt(quantity);
        this.saveCart();
        
        this.showNotification(
            'Added to Cart', 
            `${productName} added to cart (${this.cart[productId].quantity})`, 
            'success'
        );
        
        this.trackEvent('product_added_to_cart', {
            product_id: productId,
            product_name: productName,
            quantity: this.cart[productId].quantity
        });
    }

    removeFromCart(productId) {
        if (this.cart[productId]) {
            const productName = this.cart[productId].name;
            delete this.cart[productId];
            this.saveCart();
            
            this.showNotification('Removed from Cart', `${productName} removed from cart`, 'info');
        }
    }

    updateCartQuantity(productId, change) {
        if (this.cart[productId]) {
            this.cart[productId].quantity += change;
            if (this.cart[productId].quantity <= 0) {
                this.removeFromCart(productId);
            } else {
                this.saveCart();
            }
        }
    }

    clearCart() {
        this.cart = {};
        this.saveCart();
        this.showNotification('Cart Cleared', 'All items have been removed from your cart', 'info');
    }

    calculateSubtotal() {
        return Object.values(this.cart).reduce((total, item) => {
            return total + (item.price * item.quantity);
        }, 0);
    }

    updateCartDisplay() {
        const cartCount = Object.values(this.cart).reduce((sum, item) => sum + item.quantity, 0);
        
        const cartCountElements = document.querySelectorAll('.cart-count, #cartCount');
        cartCountElements.forEach(element => {
            if (element) {
                element.textContent = cartCount;
                element.style.display = cartCount > 0 ? 'flex' : 'none';
            }
        });

        const cartTotalElements = document.querySelectorAll('.cart-total, #cartTotal');
        cartTotalElements.forEach(element => {
            if (element) {
                element.textContent = `UGX ${this.calculateSubtotal().toLocaleString()}`;
            }
        });

        this.updateCartItemsDisplay();
    }

    updateCartItemsDisplay() {
        const cartItemsContainer = document.getElementById('cartItems');
        if (!cartItemsContainer) return;

        if (Object.keys(this.cart).length === 0) {
            cartItemsContainer.innerHTML = '<div class="empty-state">Your cart is empty</div>';
            return;
        }

        cartItemsContainer.innerHTML = Object.entries(this.cart).map(([id, item]) => `
            <div class="cart-item" data-product-id="${id}">
                <div class="cart-item-info">
                    <h4>${item.name}</h4>
                    <p>UGX ${item.price.toLocaleString()} each</p>
                </div>
                <div class="cart-item-controls">
                    <button class="btn btn-sm" data-cart-update data-product-id="${id}" data-change="-1">-</button>
                    <span class="cart-item-quantity">${item.quantity}</span>
                    <button class="btn btn-sm" data-cart-update data-product-id="${id}" data-change="1">+</button>
                    <button class="btn btn-danger btn-sm" data-cart-remove data-product-id="${id}">Remove</button>
                </div>
            </div>
        `).join('');
    }

    // Enhanced staff session management
    async checkStaffSession() {
        try {
            const sessionData = localStorage.getItem('staff_session');
            if (sessionData) {
                this.currentStaff = JSON.parse(sessionData);
                this.updateStaffUI();
            }
        } catch (error) {
            console.error('Session validation error:', error);
        }
    }

    updateStaffUI() {
        const staffElements = document.querySelectorAll('.staff-only');
        staffElements.forEach(el => {
            if (el) {
                el.style.display = this.currentStaff ? 'block' : 'none';
            }
        });

        const staffNameElement = document.getElementById('staffName');
        if (staffNameElement && this.currentStaff) {
            staffNameElement.textContent = this.currentStaff.full_name;
        }

        const loginElements = document.querySelectorAll('.login-only');
        loginElements.forEach(el => {
            if (el) {
                el.style.display = this.currentStaff ? 'none' : 'block';
            }
        });
    }

    async handleStaffLogin(formData) {
        const credentials = {
            username: formData.get('username'),
            password: formData.get('password')
        };

        this.showLoading('Signing in...');
        
        try {
            const result = await HealthAPI.staffLogin(credentials);
            
            if (result.success) {
                this.currentStaff = result.user;
                localStorage.setItem('staff_session', JSON.stringify(this.currentStaff));
                this.updateStaffUI();
                this.showNotification('Login Successful', 'Welcome back!', 'success');
                
                setTimeout(() => {
                    window.location.href = '/admin-dashboard.html';
                }, 1500);
            } else {
                throw new Error(result.error || 'Login failed');
            }
        } catch (error) {
            this.showNotification('Login Failed', error.message, 'error');
        } finally {
            this.hideLoading();
        }
    }

    async staffLogout() {
        try {
            await HealthAPI.staffLogout();
            localStorage.removeItem('staff_session');
            this.currentStaff = null;
            this.updateStaffUI();
            this.showNotification('Logged Out', 'You have been successfully logged out', 'success');
            
            setTimeout(() => {
                window.location.href = '/admin-login.html';
            }, 1500);
        } catch (error) {
            console.error('Logout error:', error);
            this.showNotification('Logout Error', 'Failed to log out properly', 'error');
        }
    }

    // Enhanced utility methods
    showLoading(message = 'Loading...') {
        let loader = document.querySelector('.loading-overlay');
        if (!loader) {
            loader = document.createElement('div');
            loader.className = 'loading-overlay';
            loader.innerHTML = `
                <div class="loading-content">
                    <div class="loading-spinner"></div>
                    <p class="loading-message">${message}</p>
                </div>
            `;
            document.body.appendChild(loader);
        }
        loader.style.display = 'flex';
        document.body.style.overflow = 'hidden';
    }

    hideLoading() {
        const loader = document.querySelector('.loading-overlay');
        if (loader) {
            loader.style.display = 'none';
            document.body.style.overflow = '';
        }
    }

    showNotification(title, message, type = 'info', duration = 5000) {
        const existingNotifications = document.querySelectorAll('.notification');
        existingNotifications.forEach(notification => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        });

        const notification = document.createElement('div');
        notification.className = `notification notification-${type}`;
        notification.innerHTML = `
            <div class="notification-header">
                <strong>${title}</strong>
                <button class="notification-close">&times;</button>
            </div>
            <div class="notification-body">${message}</div>
        `;
        
        const closeBtn = notification.querySelector('.notification-close');
        closeBtn.addEventListener('click', () => {
            notification.remove();
        });
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            if (notification.parentNode) {
                notification.remove();
            }
        }, duration);
        
        setTimeout(() => {
            notification.classList.add('notification-visible');
        }, 10);
    }

    handleNotificationClose(e) {
        const notification = e.target.closest('.notification');
        if (notification) {
            notification.remove();
        }
    }

    handleWhatsAppClick(e) {
        const button = e.target.closest('[data-whatsapp]');
        const defaultMessage = button.getAttribute('data-message') || 'Hello! I need assistance from CC Smart Health.';
        const phoneNumber = button.getAttribute('data-phone') || '+256776769841';
        
        WhatsAppBusiness.sendMessage(phoneNumber, defaultMessage);
        
        this.trackEvent('whatsapp_click', {
            message_type: button.getAttribute('data-message-type') || 'general'
        });
    }

    handleEmergencyCall(e) {
        e.preventDefault();
        const phoneNumber = '+256762235149';
        
        this.trackEvent('emergency_call_attempt', {
            source: e.target.closest('.emergency-btn')?.getAttribute('data-source') || 'unknown'
        });
        
        window.location.href = `tel:${phoneNumber}`;
    }

    // Enhanced connectivity monitoring
    setupConnectivityMonitoring() {
        this.isOnline = navigator.onLine;
        this.updateConnectivityStatus();
    }

    handleOnlineStatus(online) {
        this.isOnline = online;
        this.updateConnectivityStatus();
        
        if (online) {
            this.showNotification('Back Online', 'Your connection has been restored', 'success', 3000);
            this.retryFailedRequests();
        } else {
            this.showNotification('You\'re Offline', 'Some features may be limited', 'warning', 3000);
        }
    }

    updateConnectivityStatus() {
        if (this.isOnline) {
            document.body.classList.remove('offline');
        } else {
            document.body.classList.add('offline');
        }
    }

    handleVisibilityChange() {
        if (!document.hidden) {
            this.checkForUpdates();
        }
    }

    // Mobile menu management
    toggleMobileMenu() {
        const nav = document.querySelector('.main-nav');
        let overlay = document.querySelector('.nav-overlay');
        
        if (!overlay) {
            overlay = document.createElement('div');
            overlay.className = 'nav-overlay';
            overlay.addEventListener('click', () => this.toggleMobileMenu());
            document.body.appendChild(overlay);
        }
        
        nav.classList.toggle('active');
        overlay.classList.toggle('active');
        document.body.style.overflow = nav.classList.contains('active') ? 'hidden' : '';
    }

    closeMobileMenu() {
        const nav = document.querySelector('.main-nav');
        const overlay = document.querySelector('.nav-overlay');
        
        if (nav) nav.classList.remove('active');
        if (overlay) overlay.classList.remove('active');
        document.body.style.overflow = '';
    }

    // Utility functions
    sanitizeInput(input) {
        if (typeof input !== 'string') return '';
        return input.trim().replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }

    formatPhoneNumber(phone) {
        if (!phone) return '';
        return phone.replace(/\D/g, '');
    }

    isValidPhoneNumber(phone) {
        const cleaned = this.formatPhoneNumber(phone);
        return cleaned.length >= 9 && cleaned.length <= 12;
    }

    trackEvent(eventName, properties = {}) {
        console.log('Event tracked:', eventName, properties);
        
        if (typeof gtag !== 'undefined') {
            gtag('event', eventName, properties);
        }
    }

    retryFailedRequests() {
        console.log('Retrying failed requests...');
    }

    checkForUpdates() {
        console.log('Checking for updates...');
    }

    // Service Worker initialization
    initServiceWorker() {
        if ('serviceWorker' in navigator) {
            navigator.serviceWorker
                .register('/service-worker.js')
                .then(registration => {
                    console.log('✅ Service Worker registered successfully');
                    
                    if (registration.active) {
                        registration.active.postMessage({
                            type: 'PRECACHE_ASSETS'
                        });
                    }
                    
                    registration.addEventListener('updatefound', () => {
                        const newWorker = registration.installing;
                        console.log('🔄 New Service Worker found');
                        
                        newWorker.addEventListener('statechange', () => {
                            if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
                                this.showNotification(
                                    'Update Available', 
                                    'A new version is available. Refresh to update.',
                                    'info',
                                    10000
                                );
                            }
                        });
                    });
                })
                .catch(error => {
                    console.error('❌ Service Worker registration failed:', error);
                });
        }
    }

    // Page-specific initializations
    initPageSpecificFeatures() {
        this.currentPage = window.location.pathname.split('/').pop() || 'index.html';
        
        console.log(`📄 Initializing page: ${this.currentPage}`);
        
        switch(this.currentPage) {
            case 'pharmacy.html':
                this.initPharmacyPage();
                break;
            case 'lab-tests.html':
                this.initLabTestsPage();
                break;
            case 'admin-dashboard.html':
                this.initAdminDashboard();
                break;
            case 'appointment.html':
                this.initAppointmentPage();
                break;
            case 'admin-login.html':
            case 'staff-login.html':
                this.initLoginPage();
                break;
            default:
                this.initHomePage();
        }
    }

    initHomePage() {
        this.setupScrollAnimations();
        this.setupCounters();
        this.setupWhatsAppButtons();
    }

    initPharmacyPage() {
        this.loadPharmacyProducts();
        this.setupProductSearch();
        this.setupCartView();
    }

    initLabTestsPage() {
        this.loadLabTests();
        this.setupTestCategories();
    }

    initAdminDashboard() {
        this.checkStaffSession();
        this.loadDashboardData();
    }

    initAppointmentPage() {
        this.setupDatePickers();
        this.setupTimeSlots();
    }

    initLoginPage() {
        this.checkStaffSession();
    }

    setupScrollAnimations() {
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('visible');
                }
            });
        }, {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        });

        document.querySelectorAll('.fade-in, .slide-in-left, .slide-in-right').forEach(el => {
            observer.observe(el);
        });
    }

    setupCounters() {
        const counters = document.querySelectorAll('.stat-number');
        counters.forEach(counter => {
            const target = parseInt(counter.textContent);
            const increment = target / 50;
            let current = 0;

            const timer = setInterval(() => {
                current += increment;
                if (current >= target) {
                    counter.textContent = target + (counter.textContent.includes('+') ? '+' : '');
                    clearInterval(ttimer);
                } else {
                    counter.textContent = Math.floor(current) + (counter.textContent.includes('+') ? '+' : '');
                }
            }, 40);
        });
    }

    setupWhatsAppButtons() {
        document.querySelectorAll('[data-whatsapp]').forEach(button => {
            if (!button.hasListener) {
                button.addEventListener('click', (e) => {
                    this.handleWhatsAppClick(e);
                });
                button.hasListener = true;
            }
        });
    }

    setupCartView() {
        this.updateCartItemsDisplay();
    }

    // Dependency verification
    verifyJSFiles() {
        const requiredJS = [
            '/public/js/app.js',
            '/public/js/router.js',
            '/public/js/whatsapp-business.js',
            '/public/js/health-api.js',
            '/public/js/uganda-payments.js'
        ];

        console.group('🔧 JavaScript Files Verification');
        requiredJS.forEach(jsFile => {
            const scripts = Array.from(document.scripts);
            const isLoaded = scripts.some(script => script.src.includes(jsFile));
            console.log(`${isLoaded ? '✅' : '❌'} ${jsFile}: ${isLoaded ? 'Loaded' : 'Missing'}`);
        });
        console.groupEnd();
    }

    // Debug navigation setup
    debugNavigationSetup() {
        console.log('🔗 Navigation Links Check:');
        document.querySelectorAll('[data-page]').forEach(link => {
            console.log(`- ${link.getAttribute('data-page')}: href="${link.getAttribute('href')}"`);
        });
    }

    // Error boundaries and fallbacks
    setupErrorBoundaries() {
        if (typeof HealthAPI === 'undefined') {
            console.warn('HealthAPI not found, using fallback');
            this.setupFallbackAPI();
        }
        
        if (typeof WhatsAppBusiness === 'undefined') {
            console.warn('WhatsAppBusiness not found, using fallback');
            this.setupFallbackWhatsApp();
        }
        
        if (typeof UgandaPayments === 'undefined') {
            console.warn('UgandaPayments not found, using fallback');
            this.setupFallbackPayments();
        }

        // Global error handlers
        window.addEventListener('error', (event) => {
            console.error('🚨 Global Error:', event.error);
        });

        window.addEventListener('unhandledrejection', (event) => {
            console.error('🚨 Unhandled Promise Rejection:', event.reason);
        });
    }

    setupFallbackAPI() {
        window.HealthAPI = {
            createAppointment: (data) => Promise.resolve({ 
                success: true, 
                reference: 'APT-' + Date.now()
            }),
            createPharmacyOrder: (data) => Promise.resolve({ 
                success: true, 
                order_code: 'ORD-' + Date.now()
            }),
            staffLogin: (credentials) => Promise.resolve({ 
                success: true, 
                user: { 
                    id: 1, 
                    full_name: credentials.username,
                    role: 'staff' 
                } 
            }),
            staffLogout: () => Promise.resolve({ success: true }),
            validateSession: () => Promise.resolve({ valid: false })
        };
    }

    setupFallbackWhatsApp() {
        window.WhatsAppBusiness = {
            sendMessage: (phone, message) => {
                const encoded = encodeURIComponent(message);
                window.open(`https://wa.me/${phone}?text=${encoded}`, '_blank');
            }
        };
    }

    setupFallbackPayments() {
        window.UgandaPayments = {
            processPayment: (amount, phone) => Promise.resolve({ 
                success: true, 
                transaction_id: 'TXN-' + Date.now()
            })
        };
    }

    // Placeholder methods for page-specific features
    loadPharmacyProducts() {
        console.log('Loading pharmacy products...');
    }

    setupProductSearch() {
        console.log('Setting up product search...');
    }

    loadLabTests() {
        console.log('Loading lab tests...');
    }

    setupTestCategories() {
        console.log('Setting up test categories...');
    }

    loadDashboardData() {
        console.log('Loading dashboard data...');
    }

    setupDatePickers() {
        console.log('Setting up date pickers...');
    }

    setupTimeSlots() {
        console.log('Setting up time slots...');
    }

    handleLabTestSubmit(formData) {
        console.log('Lab test form submitted:', formData);
        this.showNotification('Test Request Sent', 'Your lab test request has been submitted', 'success');
    }

    handleContactSubmit(formData) {
        console.log('Contact form submitted:', formData);
        this.showNotification('Message Sent', 'Your message has been sent successfully', 'success');
    }

    handleGenericFormSubmit(formData, formId) {
        console.log('Generic form submitted:', formId, formData);
        this.showNotification('Form Submitted', 'Your information has been received', 'success');
    }
}

// Global helper functions
window.addToCart = function(productId, productName, productPrice, quantity = 1) {
    if (window.ccHealthApp) {
        window.ccHealthApp.addToCart(productId, productName, productPrice, quantity);
    }
};

window.removeFromCart = function(productId) {
    if (window.ccHealthApp) {
        window.ccHealthApp.removeFromCart(productId);
    }
};

window.updateCartQuantity = function(productId, change) {
    if (window.ccHealthApp) {
        window.ccHealthApp.updateCartQuantity(productId, change);
    }
};

window.staffLogout = function() {
    if (window.ccHealthApp) {
        window.ccHealthApp.staffLogout();
    }
};

window.toggleMobileMenu = function() {
    if (window.ccHealthApp) {
        window.ccHealthApp.toggleMobileMenu();
    }
};

window.clearCart = function() {
    if (window.ccHealthApp) {
        window.ccHealthApp.clearCart();
    }
};

// Initialize when DOM is ready
function initializeApp() {
    try {
        setTimeout(() => {
            window.ccHealthApp = new CCHealthApp();
        }, 100);
    } catch (error) {
        console.error('❌ Failed to initialize CC Smart Health App:', error);
        
        const errorMessage = document.createElement('div');
        errorMessage.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            background: #dc3545;
            color: white;
            padding: 1rem;
            text-align: center;
            z-index: 10000;
            font-family: Arial, sans-serif;
        `;
        errorMessage.textContent = 'Application failed to load. Please refresh the page.';
        document.body.appendChild(errorMessage);
    }
}

// Initialize based on document state
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initializeApp);
} else {
    initializeApp();
}