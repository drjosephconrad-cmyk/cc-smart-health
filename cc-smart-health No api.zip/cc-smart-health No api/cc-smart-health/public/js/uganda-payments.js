// Uganda Mobile Money Payment Integration - Enhanced with Validation
class UgandaPayments {
    constructor() {
        this.providers = {
            mtn: {
                name: 'MTN Mobile Money',
                number: '+256776769841',
                code: '*165#',
                ussd: '*165*',
                instructions: '1. Dial *165#\n2. Select "Send Money"\n3. Enter: +256776769841\n4. Enter amount: UGX [AMOUNT]\n5. Enter reference: [REFERENCE]\n6. Enter your PIN',
                color: '#FFC107',
                icon: '📱',
                min_amount: 500,
                max_amount: 5000000
            },
            airtel: {
                name: 'Airtel Money', 
                number: '+256709221429',
                code: '*185#',
                ussd: '*185*',
                instructions: '1. Dial *185#\n2. Select "Send Money"\n3. Enter: +256709221429\n4. Enter amount: UGX [AMOUNT]\n5. Enter reference: [REFERENCE]\n6. Enter your PIN',
                color: '#E60000',
                icon: '📲',
                min_amount: 500,
                max_amount: 5000000
            },
            cash: {
                name: 'Cash on Delivery',
                number: '',
                code: '',
                instructions: 'Pay cash when your order is delivered. Our delivery agent will provide an official receipt.',
                color: '#4CAF50',
                icon: '💵',
                min_amount: 0,
                max_amount: 1000000
            }
        };
        
        this.businessInfo = {
            name: 'CC Smart Health',
            phone: '+256762235149',
            whatsapp: '+256776769841',
            location: 'Hoima City',
            tin: 'Available on request'
        };
    }
    
    // Generate complete payment message with enhanced formatting
    generatePaymentMessage(amount, provider, orderDetails, customerName, orderCode = '') {
        const providerInfo = this.providers[provider];
        const reference = orderCode || `CC${Date.now().toString().slice(-6)}`;
        const timestamp = new Date().toLocaleString('en-UG');
        
        // Validate amount
        const amountValidation = this.validateAmount(amount, provider);
        if (!amountValidation.valid) {
            throw new Error(amountValidation.error);
        }
        
        return `💳 PAYMENT REQUEST - ${this.businessInfo.name}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

💰 **Payment Details**
• Amount: UGX ${amount.toLocaleString()}
• Method: ${providerInfo.name} ${providerInfo.icon}
• Reference: ${reference}
• Date: ${timestamp}

👤 **Customer Information**
• Name: ${customerName}
• Order: ${orderCode || 'New Order'}

📞 **Payment Instructions**
Send to: ${providerInfo.number || 'Cash on Delivery'}
${providerInfo.number ? `Reference: ${reference}` : ''}

📋 **Step by Step:**
${providerInfo.instructions.replace('[AMOUNT]', amount.toLocaleString()).replace('[REFERENCE]', reference)}

🛒 **Order Summary:**
${orderDetails}

⚠️ **Important Notes**
• Always use reference: ${reference}
• Keep payment confirmation screenshot
• Delivery: ${this.calculateDeliveryTime()}
• Issues? Call: ${this.businessInfo.phone}

🏥 **${this.businessInfo.name}**
📍 ${this.businessInfo.location} | 📞 ${this.businessInfo.phone}
✅ Official Receipt Provided`;
    }
    
    // Enhanced order summary with better formatting and validation
    generateOrderSummary(items, deliveryFee = 0, location = 'Hoima City', customerName = '') {
        if (!items || !Array.isArray(items) || items.length === 0) {
            throw new Error('Order must contain at least one item');
        }
        
        let summary = '';
        let subtotal = 0;
        let itemCount = 0;
        
        items.forEach((item, index) => {
            if (!item.name || !item.price || !item.quantity) {
                throw new Error(`Invalid item at position ${index + 1}`);
            }
            
            const itemTotal = item.price * item.quantity;
            subtotal += itemTotal;
            itemCount += item.quantity;
            
            summary += `• ${item.name} x${item.quantity} = UGX ${itemTotal.toLocaleString()}\n`;
        });
        
        const total = subtotal + deliveryFee;
        const deliveryInfo = this.getDeliveryInfo(location);
        
        const formattedSummary = `🛒 ORDER SUMMARY (${itemCount} items)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
${summary}
📍 Delivery Area: ${deliveryInfo.area}
🚚 Delivery Time: ${deliveryInfo.time}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📦 Subtotal: UGX ${subtotal.toLocaleString()}
🚚 Delivery Fee: UGX ${deliveryFee.toLocaleString()}
💰 **GRAND TOTAL: UGX ${total.toLocaleString()}**
${customerName ? `👤 Customer: ${customerName}` : ''}`;
        
        return {
            summary: formattedSummary,
            subtotal: subtotal,
            deliveryFee: deliveryFee,
            total: total,
            itemCount: itemCount,
            deliveryInfo: deliveryInfo
        };
    }
    
    // Enhanced delivery fee calculation with location-based pricing
    calculateDeliveryFee(orderAmount, location = 'Hoima City', urgent = false) {
        const deliveryFees = {
            'Hoima City': {
                freeThreshold: 50000,
                standardFee: 5000,
                urgentFee: 8000
            },
            'Kijungu': {
                freeThreshold: 75000,
                standardFee: 7000,
                urgentFee: 10000
            },
            'Bujumbura': {
                freeThreshold: 75000,
                standardFee: 8000,
                urgentFee: 12000
            },
            'Kigorobya': {
                freeThreshold: 100000,
                standardFee: 10000,
                urgentFee: 15000
            },
            'default': {
                freeThreshold: 100000,
                standardFee: 10000,
                urgentFee: 15000
            }
        };
        
        const locationFees = deliveryFees[location] || deliveryFees.default;
        const baseFee = urgent ? locationFees.urgentFee : locationFees.standardFee;
        
        if (orderAmount >= locationFees.freeThreshold) {
            return 0;
        }
        
        return baseFee;
    }
    
    // Enhanced delivery time estimation
    calculateDeliveryTime(location = 'Hoima City', urgent = false) {
        const deliveryTimes = {
            'Hoima City': {
                standard: '2-4 hours',
                urgent: '1-2 hours'
            },
            'Kijungu': {
                standard: '3-5 hours',
                urgent: '2-3 hours'
            },
            'Bujumbura': {
                standard: '4-6 hours',
                urgent: '3-4 hours'
            },
            'Kigorobya': {
                standard: '5-7 hours',
                urgent: '4-5 hours'
            },
            'default': {
                standard: '4-6 hours',
                urgent: '3-4 hours'
            }
        };
        
        const locationTimes = deliveryTimes[location] || deliveryTimes.default;
        return urgent ? locationTimes.urgent : locationTimes.standard;
    }
    
    // Get comprehensive delivery information
    getDeliveryInfo(location = 'Hoima City') {
        return {
            area: location,
            time: this.calculateDeliveryTime(location),
            urgentTime: this.calculateDeliveryTime(location, true),
            fee: this.calculateDeliveryFee(0, location),
            urgentFee: this.calculateDeliveryFee(0, location, true)
        };
    }
    
    // Enhanced phone number formatting for Uganda
    formatPhoneNumber(phone) {
        if (!phone) return '';
        
        const clean = phone.replace(/\D/g, '');
        
        if (clean.length === 9 && clean.startsWith('7')) {
            return `+256${clean}`;
        } else if (clean.length === 10 && clean.startsWith('0')) {
            return `+256${clean.substring(1)}`;
        } else if (clean.length === 12 && clean.startsWith('256')) {
            return `+${clean}`;
        } else if (clean.length === 13 && clean.startsWith('+256')) {
            return clean;
        }
        
        return phone;
    }
    
    // Enhanced Uganda phone number validation
    isValidUgandaNumber(phone) {
        const formatted = this.formatPhoneNumber(phone);
        const regex = /^\+256(7[0-9]|20)[0-9]{7}$/;
        return regex.test(formatted);
    }
    
    // Validate payment amount
    validateAmount(amount, provider) {
        const providerInfo = this.providers[provider];
        
        if (typeof amount !== 'number' || amount <= 0) {
            return { valid: false, error: 'Amount must be a positive number' };
        }
        
        if (amount < providerInfo.min_amount) {
            return { 
                valid: false, 
                error: `Minimum amount for ${providerInfo.name} is UGX ${providerInfo.min_amount.toLocaleString()}` 
            };
        }
        
        if (amount > providerInfo.max_amount) {
            return { 
                valid: false, 
                error: `Maximum amount for ${providerInfo.name} is UGX ${providerInfo.max_amount.toLocaleString()}` 
            };
        }
        
        return { valid: true };
    }
    
    // Generate USSD code for quick payment
    generateUSSDCode(amount, provider, reference) {
        const providerInfo = this.providers[provider];
        
        if (!providerInfo.ussd) {
            return null;
        }
        
        const formattedAmount = amount.toString().replace(/\D/g, '');
        const formattedReference = reference.replace(/\s/g, '');
        
        return `${providerInfo.ussd}${formattedAmount}*${providerInfo.number}*${formattedReference}#`;
    }
    
    // Get all available payment methods with details
    getPaymentMethods() {
        return Object.entries(this.providers).map(([key, provider]) => ({
            id: key,
            name: provider.name,
            icon: provider.icon,
            color: provider.color,
            instructions: provider.instructions,
            min_amount: provider.min_amount,
            max_amount: provider.max_amount,
            number: provider.number,
            ussd_template: provider.ussd ? `${provider.ussd}[amount]*[number]*[reference]#` : null
        }));
    }
    
    // Generate payment confirmation template
    generateConfirmationTemplate(orderCode, amount, method, customerName) {
        return `✅ PAYMENT CONFIRMATION - ${this.businessInfo.name}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

💰 **Payment Received**
• Order Code: ${orderCode}
• Amount: UGX ${amount.toLocaleString()}
• Method: ${method}
• Customer: ${customerName}
• Date: ${new Date().toLocaleString('en-UG')}

📦 **Order Status**
Status: Payment confirmed ✅
Next: Processing order
Delivery: ${this.calculateDeliveryTime()}

🏥 **${this.businessInfo.name}**
Thank you for your payment! Your order is being processed.`;
    }
    
    // Method to simulate payment processing (for testing)
    simulatePayment(amount, provider, reference) {
        return new Promise((resolve) => {
            setTimeout(() => {
                resolve({
                    success: true,
                    transaction_id: 'TXN_' + Date.now(),
                    amount: amount,
                    provider: provider,
                    reference: reference,
                    timestamp: new Date().toISOString()
                });
            }, 2000);
        });
    }
}

// Make available globally
window.UgandaPayments = UgandaPayments;

// Initialize payment system with enhanced setup
document.addEventListener('DOMContentLoaded', () => {
    window.paymentSystem = new UgandaPayments();
    console.log('Uganda Payments system initialized');
});