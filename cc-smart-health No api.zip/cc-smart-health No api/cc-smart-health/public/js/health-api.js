// CC Smart Health - Enhanced API Service with Better Error Handling
class HealthAPIService {
    constructor() {
        this.useAPI = false; // Start with WhatsApp, enable API later
        this.apiBase = ''; // Will be set when we deploy APIs
        this.requestTimeout = 10000; // 10 second timeout
        this.maxRetries = 2;
    }

    // Enhanced appointment management with retry logic
    async createAppointment(appointmentData) {
        return this.withRetry(async () => {
            try {
                if (this.useAPI && this.apiBase) {
                    const response = await this.fetchWithTimeout(`${this.apiBase}/appointments.php`, {
                        method: 'POST',
                        headers: { 
                            'Content-Type': 'application/json',
                            'X-Requested-With': 'XMLHttpRequest'
                        },
                        body: JSON.stringify(this.sanitizeAppointmentData(appointmentData))
                    });
                    
                    if (!response.ok) {
                        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
                    }
                    
                    const result = await response.json();
                    return result;
                }
            } catch (error) {
                console.warn('API unavailable, falling back to WhatsApp:', error);
            }
            
            // WhatsApp Fallback
            return WhatsAppBusiness.sendAppointment(appointmentData);
        });
    }

    async getAppointments(phone = null) {
        try {
            // For now, return empty array - will be implemented with backend
            return { 
                success: true, 
                data: [],
                message: 'Appointment system ready'
            };
        } catch (error) {
            return {
                success: false,
                error: 'Failed to fetch appointments',
                data: []
            };
        }
    }

    // Enhanced pharmacy order with validation
    async createPharmacyOrder(orderData) {
        return this.withRetry(async () => {
            try {
                // Validate order data
                const validation = this.validateOrderData(orderData);
                if (!validation.valid) {
                    return {
                        success: false,
                        error: validation.errors.join(', ')
                    };
                }

                if (this.useAPI && this.apiBase) {
                    const response = await this.fetchWithTimeout(`${this.apiBase}/pharmacy-orders.php`, {
                        method: 'POST',
                        headers: { 
                            'Content-Type': 'application/json',
                            'X-Requested-With': 'XMLHttpRequest'
                        },
                        body: JSON.stringify(this.sanitizeOrderData(orderData))
                    });
                    
                    if (!response.ok) {
                        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
                    }
                    
                    return await response.json();
                }
            } catch (error) {
                console.warn('API unavailable, falling back to WhatsApp:', error);
            }
            
            return WhatsAppBusiness.sendPharmacyOrder(orderData);
        });
    }

    // Enhanced lab test management
    async createLabRequest(labData) {
        return this.withRetry(async () => {
            try {
                if (this.useAPI && this.apiBase) {
                    const response = await this.fetchWithTimeout(`${this.apiBase}/lab-tests.php`, {
                        method: 'POST',
                        headers: { 
                            'Content-Type': 'application/json',
                            'X-Requested-With': 'XMLHttpRequest'
                        },
                        body: JSON.stringify(this.sanitizeLabData(labData))
                    });
                    
                    if (!response.ok) {
                        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
                    }
                    
                    return await response.json();
                }
            } catch (error) {
                console.warn('API unavailable, falling back to WhatsApp:', error);
            }
            
            return WhatsAppBusiness.sendLabTestRequest(labData);
        });
    }

    // Enhanced data fetching with caching
    async getLabTests(forceRefresh = false) {
        const cacheKey = 'lab_tests_cache';
        const cacheTime = 30 * 60 * 1000; // 30 minutes
        
        try {
            // Check cache first
            if (!forceRefresh) {
                const cached = this.getFromCache(cacheKey, cacheTime);
                if (cached) {
                    return { success: true, data: cached, cached: true };
                }
            }

            const response = await this.fetchWithTimeout('/public/lab-tests.json');
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }
            
            const data = await response.json();
            
            // Cache the response
            this.saveToCache(cacheKey, data.categories);
            
            return { success: true, data: data.categories, cached: false };
        } catch (error) {
            console.error('Failed to fetch lab tests:', error);
            
            // Try cache as fallback
            const cached = this.getFromCache(cacheKey, cacheTime * 2); // Longer cache on error
            if (cached) {
                return { success: true, data: cached, cached: true, error: 'Using cached data' };
            }
            
            return this.getFallbackLabTests();
        }
    }

    async getPharmacyProducts(forceRefresh = false) {
        const cacheKey = 'pharmacy_products_cache';
        const cacheTime = 30 * 60 * 1000; // 30 minutes
        
        try {
            // Check cache first
            if (!forceRefresh) {
                const cached = this.getFromCache(cacheKey, cacheTime);
                if (cached) {
                    return { success: true, data: cached, cached: true };
                }
            }

            const response = await this.fetchWithTimeout('/public/pharmacy-products.json');
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }
            
            const data = await response.json();
            
            // Cache the response
            this.saveToCache(cacheKey, data.categories);
            
            return { success: true, data: data.categories, cached: false };
        } catch (error) {
            console.error('Failed to fetch pharmacy products:', error);
            
            // Try cache as fallback
            const cached = this.getFromCache(cacheKey, cacheTime * 2);
            if (cached) {
                return { success: true, data: cached, cached: true, error: 'Using cached data' };
            }
            
            return this.getFallbackPharmacyProducts();
        }
    }

    // Enhanced authentication with security measures
    async staffLogin(credentials) {
        // Basic validation
        if (!credentials.username || !credentials.password) {
            return { 
                success: false, 
                error: 'Username and password are required' 
            };
        }

        // Rate limiting check
        if (this.isRateLimited('login', credentials.username)) {
            return {
                success: false,
                error: 'Too many login attempts. Please try again later.'
            };
        }

        const validUsers = {
            'admin': { 
                password: 'admin123', 
                role: 'admin', 
                name: 'System Administrator',
                permissions: ['all']
            },
            'joseph': { 
                password: 'admin123', 
                role: 'clinical_officer', 
                name: 'Joseph Alibankoha',
                permissions: ['appointments', 'patients', 'prescriptions']
            },
            'deo': { 
                password: 'admin123', 
                role: 'lab_technician', 
                name: 'Deo Katusabe',
                permissions: ['lab_tests', 'results']
            }
        };

        const user = validUsers[credentials.username];
        
        if (user && user.password === credentials.password) {
            // Record login attempt
            this.recordLoginAttempt(credentials.username, true);
            
            // Send secure login notification
            WhatsAppBusiness.sendStaffLogin(credentials, this.getDeviceInfo());
            
            // Create secure session
            const session = {
                user_id: credentials.username,
                username: credentials.username,
                full_name: user.name,
                role: user.role,
                permissions: user.permissions,
                login_time: new Date().toISOString(),
                session_id: this.generateSessionId(),
                token: this.generateToken(credentials.username, user.role)
            };
            
            // Store session securely
            this.storeSession(session);
            
            return { 
                success: true, 
                user: session,
                message: 'Login successful' 
            };
        }
        
        // Record failed attempt
        this.recordLoginAttempt(credentials.username, false);
        
        return { 
            success: false, 
            error: 'Invalid username or password' 
        };
    }

    async validateSession() {
        const session = this.getStoredSession();
        if (!session) return { valid: false };
        
        try {
            // Check session expiration (24 hours)
            const loginTime = new Date(session.login_time);
            const now = new Date();
            const hoursDiff = (now - loginTime) / (1000 * 60 * 60);
            
            if (hoursDiff > 24) {
                this.clearSession();
                return { valid: false, reason: 'Session expired' };
            }
            
            // Validate token
            if (!this.validateToken(session.token)) {
                this.clearSession();
                return { valid: false, reason: 'Invalid token' };
            }
            
            return { valid: true, user: session };
        } catch (error) {
            console.error('Session validation error:', error);
            this.clearSession();
            return { valid: false, reason: 'Validation error' };
        }
    }

    logout() {
        const session = this.getStoredSession();
        if (session) {
            // Log logout activity
            WhatsAppBusiness.sendStaffLogout(session);
        }
        
        this.clearSession();
        return { success: true, message: 'Logged out successfully' };
    }

    // Utility Methods
    async withRetry(operation, retries = this.maxRetries) {
        for (let attempt = 1; attempt <= retries; attempt++) {
            try {
                return await operation();
            } catch (error) {
                if (attempt === retries) {
                    throw error;
                }
                console.warn(`Attempt ${attempt} failed, retrying...:`, error);
                await this.delay(1000 * attempt); // Exponential backoff
            }
        }
    }

    async fetchWithTimeout(resource, options = {}) {
        const { timeout = this.requestTimeout } = options;
        
        const controller = new AbortController();
        const id = setTimeout(() => controller.abort(), timeout);
        
        try {
            const response = await fetch(resource, {
                ...options,
                signal: controller.signal
            });
            clearTimeout(id);
            return response;
        } catch (error) {
            clearTimeout(id);
            throw error;
        }
    }

    // Data sanitization methods
    sanitizeAppointmentData(data) {
        return {
            patient_name: this.sanitizeString(data.patient_name),
            patient_phone: this.sanitizePhone(data.patient_phone),
            service_type: data.service_type,
            consultation_type: data.consultation_type,
            appointment_date: data.appointment_date,
            appointment_time: data.appointment_time,
            symptoms: this.sanitizeString(data.symptoms),
            location: this.sanitizeString(data.location),
            emergency_contact: this.sanitizePhone(data.emergency_contact),
            special_requirements: this.sanitizeString(data.special_requirements),
            timestamp: new Date().toISOString(),
            source: 'web_app'
        };
    }

    sanitizeOrderData(data) {
        return {
            customer_name: this.sanitizeString(data.customer_name),
            customer_phone: this.sanitizePhone(data.customer_phone),
            delivery_address: this.sanitizeString(data.delivery_address),
            items: data.items,
            subtotal: data.subtotal,
            delivery_fee: data.delivery_fee,
            total_amount: data.total_amount,
            payment_method: data.payment_method,
            special_instructions: this.sanitizeString(data.special_instructions),
            timestamp: new Date().toISOString(),
            source: 'web_app'
        };
    }

    sanitizeLabData(data) {
        return {
            patient_name: this.sanitizeString(data.patient_name),
            patient_phone: this.sanitizePhone(data.patient_phone),
            patient_email: this.sanitizeEmail(data.patient_email),
            tests: data.tests,
            total_amount: data.total_amount,
            special_instructions: this.sanitizeString(data.special_instructions),
            timestamp: new Date().toISOString(),
            source: 'web_app'
        };
    }

    sanitizeString(str) {
        if (typeof str !== 'string') return '';
        return str.trim().replace(/[<>]/g, '');
    }

    sanitizePhone(phone) {
        if (typeof phone !== 'string') return '';
        return phone.replace(/\D/g, '').slice(0, 15);
    }

    sanitizeEmail(email) {
        if (!email) return '';
        return email.trim().toLowerCase();
    }

    // Validation methods
    validateOrderData(orderData) {
        const errors = [];
        
        if (!orderData.customer_name?.trim()) {
            errors.push('Customer name is required');
        }
        
        if (!orderData.customer_phone?.trim()) {
            errors.push('Phone number is required');
        }
        
        if (!orderData.delivery_address?.trim()) {
            errors.push('Delivery address is required');
        }
        
        if (!orderData.items || orderData.items.length === 0) {
            errors.push('At least one item is required');
        }
        
        return {
            valid: errors.length === 0,
            errors: errors
        };
    }

    // Cache management
    saveToCache(key, data) {
        try {
            const cacheItem = {
                data: data,
                timestamp: Date.now()
            };
            localStorage.setItem(`health_cache_${key}`, JSON.stringify(cacheItem));
        } catch (error) {
            console.warn('Failed to save to cache:', error);
        }
    }

    getFromCache(key, maxAge) {
        try {
            const cached = localStorage.getItem(`health_cache_${key}`);
            if (!cached) return null;
            
            const cacheItem = JSON.parse(cached);
            const age = Date.now() - cacheItem.timestamp;
            
            if (age > maxAge) {
                localStorage.removeItem(`health_cache_${key}`);
                return null;
            }
            
            return cacheItem.data;
        } catch (error) {
            console.warn('Failed to read from cache:', error);
            return null;
        }
    }

    // Security methods
    generateSessionId() {
        return 'sess_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    }

    generateToken(username, role) {
        const payload = {
            user_id: username,
            role: role,
            timestamp: Date.now(),
            session_id: this.generateSessionId()
        };
        return btoa(JSON.stringify(payload));
    }

    validateToken(token) {
        try {
            const payload = JSON.parse(atob(token));
            const age = Date.now() - payload.timestamp;
            return age < (24 * 60 * 60 * 1000); // 24 hours
        } catch (error) {
            return false;
        }
    }

    storeSession(session) {
        try {
            localStorage.setItem('health_staff_session', JSON.stringify(session));
        } catch (error) {
            console.error('Failed to store session:', error);
        }
    }

    getStoredSession() {
        try {
            return JSON.parse(localStorage.getItem('health_staff_session'));
        } catch (error) {
            return null;
        }
    }

    clearSession() {
        localStorage.removeItem('health_staff_session');
    }

    isRateLimited(action, identifier) {
        const key = `rate_limit_${action}_${identifier}`;
        const now = Date.now();
        const window = 15 * 60 * 1000; // 15 minutes
        const maxAttempts = 5;
        
        try {
            const attempts = JSON.parse(localStorage.getItem(key) || '[]');
            const recentAttempts = attempts.filter(time => now - time < window);
            
            if (recentAttempts.length >= maxAttempts) {
                return true;
            }
            
            recentAttempts.push(now);
            localStorage.setItem(key, JSON.stringify(recentAttempts));
            return false;
        } catch (error) {
            return false;
        }
    }

    recordLoginAttempt(username, success) {
        const attempts = JSON.parse(localStorage.getItem('login_attempts') || '[]');
        attempts.push({
            username: username,
            success: success,
            timestamp: new Date().toISOString(),
            userAgent: navigator.userAgent
        });
        
        // Keep only last 100 attempts
        if (attempts.length > 100) {
            attempts.splice(0, attempts.length - 100);
        }
        
        localStorage.setItem('login_attempts', JSON.stringify(attempts));
    }

    getDeviceInfo() {
        const ua = navigator.userAgent;
        let device = 'Unknown Device';
        
        if (ua.includes('Mobile')) device = 'Mobile';
        if (ua.includes('Tablet')) device = 'Tablet';
        if (!ua.includes('Mobile') && !ua.includes('Tablet')) device = 'Desktop';
        
        return `${device} - ${navigator.platform}`;
    }

    delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    // Fallback data
    getFallbackLabTests() {
        return {
            success: true,
            data: [
                {
                    name: "Rapid Diagnostic Tests",
                    tests: [
                        { id: "malaria-rdt", name: "Malaria Rapid Test", price: 10000, duration: "30 min" },
                        { id: "typhoid-rapid", name: "Typhoid Test", price: 12000, duration: "30 min" }
                    ]
                }
            ],
            fallback: true
        };
    }

    getFallbackPharmacyProducts() {
        return {
            success: true,
            data: [
                {
                    name: "Common Medicines",
                    products: [
                        { id: "paracetamol", name: "Paracetamol 500mg", price: 1000, pack: "Strip of 10 tabs" },
                        { id: "ibuprofen", name: "Ibuprofen 200mg", price: 1000, pack: "Strip of 10 tabs" }
                    ]
                }
            ],
            fallback: true
        };
    }
}

// Initialize globally
window.HealthAPI = new HealthAPIService();
// In CCHealthApp class
verifyAPIServices() 
{
    console.group('🌐 API Services Verification');
    
    const services = {
        'HealthAPI': typeof HealthAPI !== 'undefined',
        'WhatsAppBusiness': typeof WhatsAppBusiness !== 'undefined',
        'UgandaPayments': typeof UgandaPayments !== 'undefined',
        'HealthRouter': typeof HealthRouter !== 'undefined'
    };

    Object.entries(services).forEach(([service, loaded]) => {
        console.log(`${loaded ? '✅' : '❌'} ${service}: ${loaded ? 'Available' : 'Not Loaded'}`);
    });
    
    console.groupEnd();
}