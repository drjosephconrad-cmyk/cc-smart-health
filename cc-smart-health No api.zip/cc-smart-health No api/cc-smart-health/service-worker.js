// CC Smart Health - Production Service Worker v4.0
const CACHE_VERSION = 'v4.0-production';
const CACHE_NAME = `cc-smart-health-${CACHE_VERSION}`;
const RUNTIME_CACHE = 'cc-health-runtime';

// Core assets that are essential for the app to work
const CORE_ASSETS = [
    '/',
    '/index.html',
    '/offline.html',
    '/public/css/style.css',
    '/public/js/app.js',
    '/manifest.json'
];

// Additional pages and resources (cached on-demand)
const APP_ASSETS = [
    '/about.html',
    '/services.html', 
    '/doctors.html',
    '/lab-tests.html',
    '/pharmacy.html',
    '/appointment.html',
    '/contact.html',
    '/help.html',
    '/patient-dashboard.html',
    '/admin-login.html',
    '/admin-dashboard.html',
    '/staff-login.html',
    '/public/js/router.js',
    '/public/js/whatsapp-business.js',
    '/public/js/health-api.js',
    '/public/js/uganda-payments.js',
    '/public/images/logo.jpeg',
    '/public/images/medical-pattern-1.jpg',
    '/public/images/medical-pattern-2.jpg',
    '/public/images/medical-pattern-3.jpg',
    '/public/images/icon-192x192.png',
    '/public/images/icon-512x512.png'
];

// Install - Cache core assets only
self.addEventListener('install', event => {
    console.log('🏥 Service Worker: Installing...');
    
    event.waitUntil(
        caches.open(CACHE_NAME)
            .then(cache => {
                console.log('✅ Caching core assets');
                return cache.addAll(CORE_ASSETS);
            })
            .then(() => {
                console.log('✅ Core assets cached');
                return self.skipWaiting();
            })
            .catch(error => {
                console.error('❌ Cache installation failed:', error);
            })
    );
});

// Activate - Clean up old caches
self.addEventListener('activate', event => {
    console.log('🔄 Service Worker: Activating...');
    
    event.waitUntil(
        Promise.all([
            cleanupOldCaches(),
            self.clients.claim()
        ]).then(() => {
            console.log('✅ Service Worker activated');
        })
    );
});

// Fetch - Smart caching strategy
self.addEventListener('fetch', event => {
    const { request } = event;
    const url = new URL(request.url);

    // Skip non-GET requests and cross-origin requests
    if (request.method !== 'GET' || url.origin !== self.location.origin) {
        return;
    }

    event.respondWith(
        handleFetch(request)
    );
});

async function handleFetch(request) {
    const url = new URL(request.url);
    
    try {
        // Strategy: Network First for HTML, Cache First for static assets
        if (request.headers.get('accept')?.includes('text/html')) {
            return await networkFirst(request);
        } else {
            return await cacheFirst(request);
        }
    } catch (error) {
        console.warn('Fetch failed, serving fallback:', error);
        return serveFallback(request);
    }
}

// Network First strategy for HTML pages
async function networkFirst(request) {
    try {
        const networkResponse = await fetch(request);
        
        if (networkResponse.ok) {
            // Cache the successful response
            const cache = await caches.open(RUNTIME_CACHE);
            await cache.put(request, networkResponse.clone());
            return networkResponse;
        }
        throw new Error('Network response not ok');
    } catch (error) {
        // Network failed, try cache
        const cachedResponse = await caches.match(request);
        if (cachedResponse) {
            return cachedResponse;
        }
        
        // No cache, serve offline page for HTML requests
        if (request.headers.get('accept')?.includes('text/html')) {
            return caches.match('/offline.html');
        }
        
        throw error;
    }
}

// Cache First strategy for static assets
async function cacheFirst(request) {
    const cachedResponse = await caches.match(request);
    
    if (cachedResponse) {
        // Update cache in background
        updateCacheInBackground(request);
        return cachedResponse;
    }
    
    // Not in cache, fetch from network
    try {
        const networkResponse = await fetch(request);
        
        if (networkResponse.ok) {
            const cache = await caches.open(RUNTIME_CACHE);
            await cache.put(request, networkResponse.clone());
        }
        
        return networkResponse;
    } catch (error) {
        // For images, serve placeholder
        if (request.url.match(/\.(jpg|jpeg|png|gif|webp)$/i)) {
            return serveImagePlaceholder();
        }
        
        throw error;
    }
}

// Background cache update
async function updateCacheInBackground(request) {
    try {
        const networkResponse = await fetch(request);
        if (networkResponse.ok) {
            const cache = await caches.open(RUNTIME_CACHE);
            await cache.put(request, networkResponse.clone());
        }
    } catch (error) {
        // Silent fail for background updates
    }
}

// Fallback responses
async function serveFallback(request) {
    if (request.headers.get('accept')?.includes('text/html')) {
        const offlinePage = await caches.match('/offline.html');
        if (offlinePage) return offlinePage;
    }
    
    // Generic fallback response
    return new Response('Service unavailable - offline', {
        status: 503,
        headers: { 'Content-Type': 'text/plain' }
    });
}

// Image placeholder for failed images
function serveImagePlaceholder() {
    const svg = `
        <svg width="200" height="200" xmlns="http://www.w3.org/2000/svg">
            <rect width="100%" height="100%" fill="#f8f9fa"/>
            <circle cx="100" cy="80" r="30" fill="#e9ecef"/>
            <path d="M50 140 L150 140" stroke="#dee2e6" stroke-width="2"/>
            <text x="100" y="180" text-anchor="middle" font-family="Arial" font-size="12" fill="#6c757d">
                CC Smart Health
            </text>
        </svg>
    `;
    
    return new Response(svg, {
        headers: { 
            'Content-Type': 'image/svg+xml',
            'Cache-Control': 'public, max-age=86400'
        }
    });
}

// Cache cleanup
async function cleanupOldCaches() {
    const cacheNames = await caches.keys();
    const deletePromises = cacheNames.map(cacheName => {
        if (cacheName !== CACHE_NAME && cacheName.startsWith('cc-smart-health')) {
            console.log('🗑️ Deleting old cache:', cacheName);
            return caches.delete(cacheName);
        }
    });
    
    return Promise.all(deletePromises);
}

// Pre-cache additional assets in background
self.addEventListener('message', event => {
    if (event.data && event.data.type === 'PRECACHE_ASSETS') {
        precacheAdditionalAssets();
    }
});

async function precacheAdditionalAssets() {
    try {
        const cache = await caches.open(RUNTIME_CACHE);
        await cache.addAll(APP_ASSETS);
        console.log('✅ Additional assets pre-cached');
    } catch (error) {
        console.warn('Pre-caching failed:', error);
    }
}

console.log('🏥 CC Smart Health Service Worker loaded successfully');